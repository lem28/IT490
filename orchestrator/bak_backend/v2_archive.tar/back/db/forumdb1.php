<?php
/* Database connection settings */
$host = '192.168.43.15';
$user = 'usr';
$dbpass = 'password';
$db = 'forum';
$forum = new mysqli($host,$user,$dbpass,$db);

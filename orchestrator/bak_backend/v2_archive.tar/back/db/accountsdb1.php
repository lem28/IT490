<?php
/* Database connection settings */
$host = '192.168.43.15';
$user = 'usr';
$dbpass = 'password';
$db = 'accounts';
$mysqli = new mysqli($host,$user,$dbpass,$db);

<?php
/* Database connection settings */
$host = '192.168.43.17';
$user = 'usr';
$dbpass = 'password';
$db = 'forum';
$forum = new mysqli($host,$user,$dbpass,$db);
if($forum->connect_errno){
  //echo "\nMaster server down, switching to backup...\n";
  $host = '192.168.43.25';
  $user = 'usr';
  $dbpass = 'password';
  $db = 'forum';
  $forum = new mysqli($host,$user,$dbpass,$db) or die($forum->error);
}
else{
  //echo "Using master.\n";
}

<?php
/* Database connection settings */
$host = '192.168.43.16';
$user = 'usr';
$dbpass = 'password';
$db = 'forum';
$forum = new mysqli($host,$user,$dbpass,$db);

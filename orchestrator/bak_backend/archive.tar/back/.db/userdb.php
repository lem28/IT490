<?php
/* Database connection settings */
$host = '192.168.43.17';
$dbuser = 'usr';
$dbpass = 'password';
$db = 'userdata';
$user = new mysqli($host,$dbuser,$dbpass,$db);
if($user->connect_errno){
  echo "\nMaster server down, switching to backup...\n";
  $host = '192.168.43.25';
  $dbuser = 'usr';
  $dbpass = 'password';
  $db = 'userdata';
  $user = new mysqli($host,$dbuser,$dbpass,$db) or die($user->error);
}
else{
  echo "Using master.\n";
}
